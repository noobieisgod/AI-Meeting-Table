# Android Test Plan

## Build Verification

- Configure with a desktop Qt kit for compile validation.
- Configure with a Qt Android arm64-v8a kit.
- Build Debug APK.
- Build Release APK.
- Generate signed Release AAB.
- Inspect manifest for target SDK, min SDK, package id, permissions, and exported activity.

## Functional Testing

- Create tables with 1 to 8 seats.
- Search, select, duplicate, rename, pin, unpin, and delete tables.
- Configure occupied and empty seats.
- Validate exactly one Final Decision Maker when running.
- Select OpenAI, Gemini, and Anthropic providers.
- Select model and effort levels.
- Save and reload provider API keys.
- Refresh model catalog after saving keys.
- Send user messages.
- Run full sessions through Research, Planning, Execution, Quality Control, Present, and Completed.
- Stop a session manually.
- Pause and resume during delayed turns.
- Trigger continuation prompts through low budgets or time limits.
- Queue user input during a running session.
- Generate and display artifact entries.
- Display logs and transcript after restart.

## Attachment Testing

- Import a text file.
- Import an image.
- Import a PDF.
- Confirm imported files are copied into app-private storage.
- Confirm hashes are generated.
- Confirm provider upload handles are saved after successful provider requests.
- Remove an attachment before running.
- Add an attachment during a running session and confirm it is queued for the next phase.

## Android Lifecycle Testing

- Rotate phone portrait to landscape and back.
- Rotate tablet landscape to portrait and back.
- Background the app during an idle session.
- Background the app during an in-flight provider request.
- Return from background and confirm state refreshes.
- Kill and relaunch the app after transcript, seat, and settings changes.
- Confirm selected table restoration.

## UI And Accessibility Testing

- Verify phone portrait layout at 360 dp width.
- Verify tablet split layout at 800 dp width or greater.
- Verify text wrapping in transcript cards and seat buttons.
- Verify large touch targets for seats, run, pause, stop, send, and attachment.
- Verify screen reader labels for symbolic buttons.
- Verify light theme contrast.
- Verify software keyboard does not block the composer.

## Failure Testing

- Missing API key.
- Invalid API key.
- Provider HTTP 400, 401, 429, and 500 responses.
- Network unavailable.
- Provider timeout.
- Attachment import failure.
- SQLite initialization failure.
- Empty provider response.
- Budget limits and safety reserve limits.
